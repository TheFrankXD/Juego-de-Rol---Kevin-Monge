let poema = "inicio del poema";
console.log(poema);

let calificacionFinal = 91; //int
console.log("calificacionFinal" ,  calificacionFinal, typeof(calificacionFinal)); 
let nombre = "Kevin Monge";
console.log("nombre", nombre , typeof(nombre));
console.log("primer elemento", nombre[0])

// nombre[0 = 'R'; //cadeba son inmutables
console.log("nombre", nombre, typeof(nombre))
let estaVivo = true;
console.log("estaVivo?", estaVivo, typeof(estaVivo));

let estatura = 1.65
console.log("estatura", estatura, typeof(estatura));

//Tipo de dato no primitivo
let calificiones = [80,90,100,100];
console.log("calificiones", calificiones, typeof(calificiones));
console.log(calificiones[0]);

// Funciones Math
const pi = Math.PI;
console.log("Numero PI: ", pi);
console.log("Redondear PI: ",Math.round(pi));
console.log("Redondear hacia abajo: ", Math.floor(9.9));
console.log("Redondear hacia arriba: ", Math.ceil(9.9));
console.log("Mayor calificación: ", Math.max(10,7,8));
console.log("Mayor calificación arreglo: ", Math.max(...calificiones)); //El puntopuntopunto es para descomprimir los objetos por ejemplo el arreglo, ya que como tal el Math no maneja objetos
console.log("Menor calificación arreglo: ", Math.min(...calificiones));

//Random
console.log("Numero aleatorio: ", Math.random());
console.log("Numero del 1 al 10: ", Math.round(Math.random()*10));
console.log("Raiz Cuadrada de 4: ", Math.sqrt(4));
console.log("Potencia 2 a la 16: ", Math.pow(2,16));

//
let escuela = "Unisierra"
let reflexion = `
Mi reflexión: ${escuela} \n
No sé de la vida Carlos \n
Mucho menos del amor Isac \n
\'Lo que sea no sé\' dice Ruben \n
Pero no compila \" Kevin \" \n
Que le voy a preguntar al ChatGPT dice Majo \n
Las funciones ya no funcionan  \t Chan chan Channnnn \n
Sufrir para menecer \t dice carlos \n
El hotdog más cercano del sandwich o del taco \n
Ante la duda ... \n
Camarón que se duerme ... Adrian \n
La banda dejó de tocar ... Memounstruo \n
A caballos regalado no se le vira lo torcido ... Nico\n
`;
console.log(reflexion);


//Pedir un numero 
let sigue = true;
do{
    let numero = prompt("Ingrese un numero");
    if (numero% 2 == 0){
        alert("El numero es par")
    } else {
        alert("EL numero es impar");
    }
    sigue = comfirm("Desea continuar? ");
} while (siguie);

