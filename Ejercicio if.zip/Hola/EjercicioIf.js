
let continuar = true;

do{
    let opcion = prompt("Ingrese opcón: \n 1.-Area Triangulo \n 2.-Area Rectangulo \n 3.-Perimetro Rectangulo \n 4.-y=x^2+6x+9");

    if(opcion === "1"){
        let altura = parseFloat(prompt("Ingrese la altura"));
        let base = parseFloat(prompt("Ingrese la Base"));
        alert("El Area del Triangulo es: " +  altura*base* (1/2));
    } else if (opcion === "2") {
        let largo = parseFloat(prompt("Ingrese el Largo"));
        let ancho = parseFloat(prompt("Ingrese el Ancho"));
        alert("El area del Rectangulo es: " + largo*ancho);
    } else if (opcion ===  "3"){
        let largo2 = parseFloat(prompt("Ingrese el Largo"));
        let ancho2 = parseFloat(prompt("Ingrese el Ancho"));
        alert("El perimetro del Rectangulo es: " + 2*(largo2+ancho2));
    } else if (opcion === "4"){
        let x = parseFloat(prompt("Ingrese X:"));
        let y =  Math.pow(x,2) + 6*x + 9;
        alert("Y es igual a " + y);
    } else {
        continuar=flase;
    }

}while(continuar);